@extends('layouts.app')
@section('content')
    <div class="container">
        <h3>DAFTAR GOLONGAN</h3>
        @if (session()->has('success'))
        <div class="alert alert-success" role="alert">
            {{ session ('success')}}
        </div>
        @endif
        <a class="btn btn-success btn-sm float-end mb-4 p-2" href="{{ url('golongan/create')}}">Tambah Golongan +</a>
        <table class="table-bordered table table-success table-striped">
            <tr class="table-dark ">
                <td>NO</td>
                <td>KODE</td>
                <td>NAMA</td>
                <td>AKSI</td>
            </tr>
            @foreach ($rows as $row)
            <tr>
                <td>{{ $row->gol_id}}</td>
                <td>{{ $row->gol_kode}}</td>
                <td>{{ $row->gol_nama}}</td>
                <td class="d-flex justify-content-center">
                    <a class="btn btn-info btn-sm float me-2 rounded-start-pill" href="{{url('golongan/' .$row->gol_id. '/edit')}}">Edit</a>
                    <form action="{{url('golongan/' .$row->gol_id)}}" method="post">
                        @method('DELETE')
                        @csrf
                        <button class="btn btn-danger btn-sm float ms-2 rounded-end-circle" onclick="return confirm('Apakah yakin ingin dihapus')">Hapus</button>
                    </form>
                </td>
            </tr>
            @endforeach
        </table>
    </div>
@endsection